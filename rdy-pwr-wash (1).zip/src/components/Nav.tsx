import { useEffect, useState } from "react";
import { Droplets } from "lucide-react";
import { cn } from "@/utils/cn";

const links = [
  { href: "#leaderboard", label: "Rankings" },
  { href: "#scorecard", label: "Scorecard" },
  { href: "#head-to-head", label: "Head-to-Head" },
  { href: "#why", label: "Why #1" },
  { href: "#results", label: "Results" },
  { href: "#reviews", label: "Reviews" },
  { href: "#faq", label: "FAQ" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled ? "border-b border-white/10 bg-abyss/85 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <a href="#top" className="flex shrink-0 items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-spray to-lagoon shadow-lg shadow-spray/20">
            <Droplets className="h-5 w-5 text-abyss" strokeWidth={2.5} />
          </span>
          <span className="font-display text-lg font-extrabold tracking-tight text-foam">
            Wash Report <span className="text-spray">O'ahu</span>
          </span>
        </a>

        {/* Single-row nav — scrolls sideways on small screens, no dropdown */}
        <nav className="mask-fade-x min-w-0 flex-1 overflow-x-auto lg:overflow-visible">
          <div className="flex items-center justify-end gap-5 whitespace-nowrap sm:gap-6 lg:justify-center">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm font-medium text-white/70 transition hover:text-spray"
              >
                {l.label}
              </a>
            ))}
          </div>
        </nav>
      </div>
    </header>
  );
}
